package com.faw.car.media.service;

import android.service.notification.NotificationListenerService;

public class NotificationListener extends NotificationListenerService {
    public NotificationListener() {
    }
}
